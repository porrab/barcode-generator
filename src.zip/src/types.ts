export interface AssetData {
  No: number;
  "Organization Name": string;
  "Staff ID": string | number;
  "Full Name": string;
}
