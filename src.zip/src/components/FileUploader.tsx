import React from "react";
import * as XLSX from "xlsx";
import { type AssetData } from "../types";
import { Box, Typography, Paper, styled } from "@mui/material";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";

interface Props {
  onDataLoaded: (data: AssetData[]) => void;
}

// สร้าง Styled Component สำหรับ Dropzone
const UploadBox = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(6),
  textAlign: "center",
  cursor: "pointer",
  border: `2px dashed ${theme.palette.divider}`,
  backgroundColor: theme.palette.background.default,
  transition: "all 0.3s ease",
  "&:hover": {
    borderColor: theme.palette.primary.main,
    backgroundColor: theme.palette.action.hover,
    transform: "translateY(-2px)",
  },
}));

export const FileUploader: React.FC<Props> = ({ onDataLoaded }) => {
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const arrayBuffer = evt.target?.result;
      if (arrayBuffer) {
        const wb = XLSX.read(arrayBuffer, { type: "array" });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const parsedData = XLSX.utils.sheet_to_json<AssetData>(ws);
        onDataLoaded(parsedData);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  return (
    <Box sx={{ maxWidth: 600, mx: "auto", mt: 4 }}>
      <label htmlFor="upload-excel">
        <input
          accept=".xlsx, .xls, .csv"
          style={{ display: "none" }}
          id="upload-excel"
          type="file"
          onChange={handleFileUpload}
        />
        <UploadBox elevation={0}>
          <CloudUploadIcon
            sx={{ fontSize: 60, color: "primary.main", mb: 2 }}
          />
          <Typography variant="h6" color="textPrimary" gutterBottom>
            Upload Excel File
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Click here to browse your file (.xlsx, .csv)
          </Typography>
        </UploadBox>
      </label>
    </Box>
  );
};
