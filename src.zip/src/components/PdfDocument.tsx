import React from "react";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Image,
} from "@react-pdf/renderer";
import { type AssetData } from "../types";
import jsBarcode from "jsbarcode";

const styles = StyleSheet.create({
  page: {
    flexDirection: "row",
    flexWrap: "wrap",
    padding: 20,
    alignContent: "flex-start",
  },
  card: {
    width: "33%",
    height: 90,
    padding: 5,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#eee",
    marginBottom: 10,
  },
  barcodeImage: {
    width: 150,
    height: 40,
    marginBottom: 5,
  },
  textRow: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  text: {
    fontSize: 10,
    fontFamily: "Helvetica",
  },
  bold: {
    fontWeight: "bold",
  },
});

// ฟังก์ชันแปลง Barcode เป็น Image Data URL (Base64)
const generateBarcodeDataUrl = (text: string) => {
  const canvas = document.createElement("canvas");
  jsBarcode(canvas, text, {
    format: "CODE128",
    displayValue: false,
    width: 2,
    height: 40,
    margin: 0,
  });
  return canvas.toDataURL("image/png");
};

interface Props {
  data: AssetData[];
}

export const PdfDocument: React.FC<Props> = ({ data }) => {
  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {data.map((item, index) => {
          // สร้างรูปบาร์โค้ดเตรียมไว้
          const barcodeUrl = generateBarcodeDataUrl(
            item["Staff ID"] ? String(item["Staff ID"]) : "NO-ID",
          );

          return (
            <View key={index} style={styles.card} wrap={false}>
              {/* รูป Barcode */}
              <Image src={barcodeUrl} style={styles.barcodeImage} />

              {/* ข้อความ TTB 54389 Manee */}
              <View style={styles.textRow}>
                <Text style={[styles.text]}>{item["Organization Name"]}</Text>
                <Text style={styles.text}> {item["Staff ID"]} </Text>
                <Text style={styles.text}> {item["Full Name"]}</Text>
              </View>
            </View>
          );
        })}
      </Page>
    </Document>
  );
};
